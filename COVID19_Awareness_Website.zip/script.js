const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

menuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

document.querySelectorAll(".faq-question").forEach(button => {
  button.addEventListener("click", () => {
    const wasActive = button.classList.contains("active");
    document.querySelectorAll(".faq-question").forEach(b => b.classList.remove("active"));
    if (!wasActive) button.classList.add("active");
    button.querySelector("span").textContent = button.classList.contains("active") ? "−" : "+";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();
